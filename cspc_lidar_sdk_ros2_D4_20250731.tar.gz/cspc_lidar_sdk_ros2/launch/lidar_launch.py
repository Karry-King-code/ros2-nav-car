
from ament_index_python.packages import get_package_share_directory

from launch import LaunchDescription
from launch_ros.actions import Node
from launch.actions import DeclareLaunchArgument
from launch.substitutions import LaunchConfiguration
from launch.actions import LogInfo

import os


def generate_launch_description():
    share_dir = get_package_share_directory('cspc_lidar')
    parameter_file = LaunchConfiguration('params_file')
    node_name = 'cspc_lidar'

    params_declare = DeclareLaunchArgument('params_file',
                                           default_value=os.path.join(
                                               share_dir, 'params', 'cspc_lidar.yaml'),
                                           description='FPath to the ROS2 parameters file to use.')

    driver_node = Node(package='cspc_lidar',
                                executable='cspc_lidar',
                                name='cspc_lidar',
                                output='screen',
                                emulate_tty=True,
                                parameters=[parameter_file],
                                namespace='/',
                                )


    return LaunchDescription([
        params_declare,
        driver_node,
    ])
